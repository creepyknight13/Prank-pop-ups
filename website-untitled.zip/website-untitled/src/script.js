let isPrankActive = true;

function vibrateDevice() {

    if ('vibrate' in navigator && isPrankActive) {

        // Vibration pattern: 200ms on, 100ms off, repeat

        navigator.vibrate([200, 100, 200, 100, 200]);

        setTimeout(vibrateDevice, 1000); // Repeat vibration

    }

}

function stopPrank() {

    isPrankActive = false;

    document.querySelector('.hacked-screen').

        <p>This was just a prank! Your device is safe. 😜</p>

        <p>Reload the page to try again.</p>

    `;

}

window.onload = () => {

    // Start vibration (works only on mobile with permission)

    if ('vibrate' in navigator) {

        vibrateDevice();

    } else {

        console.log("Vibration API not supported on this device.");

    }

    

    // Stop prank on key press (desktop) or touch (mobile)

    document.addEventListener('keydown', stopPrank, { once: true });

    document.addEventListener('touchstart', stopPrank, { once: true });

};